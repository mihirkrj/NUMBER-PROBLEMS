#include <stdio.h>
#include <stdbool.h>

_Bool isHarshad(int num)
{
    int sumDigits = 0, temp = num;
    while (num > 0)
    {
        sumDigits += num % 10;
        num /= 10;
    }
    return (temp % sumDigits == 0);
}

_Bool isMagic(int num)
{
    int sumDigits = 0;
    while (num >= 10)
    {
        while (num > 0)
        {
            sumDigits += num % 10;
            num /= 10;
        }
        num = sumDigits;
        sumDigits = 0;
    }
    return (num == 1);
}

_Bool isHarshadMagic(int number)
{
    return isHarshad(number) && isMagic(number);
}

int main()
{
    int x;
    printf("Enter a number: ");
    scanf("%d", &x);

    if (x <= 0)
    {
        printf("Invalid Input\n");
        return 1;
    }

    if (isHarshadMagic(x))
    {
        printf("The number is a Harshad Magic Number.\n");
    }
    else
    {
        printf("The number is not a Harshad Magic Number.\n");
    }

    return 0;
}
