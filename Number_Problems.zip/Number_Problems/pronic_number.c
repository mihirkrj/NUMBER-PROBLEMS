#include <stdio.h>
#include <stdbool.h>

_Bool checkPronicNumber(int number)
{
    int i = 1;
    while (i * (i + 1) <= number)
    {
        if (i * (i + 1) == number)
        {
            return true;
        }
        i++;
    }
    return false;
}

int main()
{
    int number;

    printf("Enter a number: ");
    if (scanf("%d", &number) != 1 || number <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (checkPronicNumber(number))
    {
        printf("The number is a Pronic Number.\n");
    }
    else
    {
        printf("The number is not a Pronic Number.\n");
    }

    return 0;
}
