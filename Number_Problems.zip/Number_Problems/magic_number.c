#include <stdio.h>
#include <stdbool.h>

_Bool isMagicNumber(int number)
{
    int sum;
    while (number >= 10)
    {
        sum = 0;
        while (number > 0)
        {
            sum += number % 10;
            number /= 10;
        }
        number = sum;
    }
    return number == 1;
}

int main()
{
    int x;
    printf("Enter a number: ");
    scanf("%d", &x);

    if (x <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (isMagicNumber(x))
    {
        printf("The number is a Magic Number.\n");
    }
    else
    {
        printf("The number is not a Magic Number.\n");
    }

    return 0;
}
