#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

_Bool checkDuck(int num)
{
    int digit;
    _Bool hasZero = false;

    if (num % 10 == 0)
    {
        return false;
    }

    while (num > 0)
    {
        digit = num % 10;
        if (digit == 0)
        {
            hasZero = true;
            break;
        }
        num /= 10;
    }

    return hasZero;
}

int main()
{
    int input;
    printf("Enter a number: ");
    scanf("%d", &input);

    if (input <= 0)
    {
        printf("Invalid input. Please enter a positive number.\n");
        return 1;
    }

    if (checkDuck(input))
    {
        printf("This number is a Duck Number.\n");
    }
    else
    {
        printf("This number is not a Duck Number.\n");
    }

    return 0;
}
