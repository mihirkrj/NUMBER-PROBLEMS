#include <stdio.h>
#include <stdbool.h>

void checkTribonacci(int number)
{
    int a = 0, b = 1, c = 1, nextTerm = 0;

    printf("%d, %d, %d, ", a, b, c);

    while (nextTerm < number)
    {
        nextTerm = a + b + c;
        if (nextTerm == number)
        {
            printf("%d\n", nextTerm);
            printf("%d found in the sequence.\n", number);
            return;
        }
        printf("%d, ", nextTerm);

        a = b;
        b = c;
        c = nextTerm;
    }

    printf("\n%d not found in the sequence.\n", number);
}

int main()
{
    int num;

    printf("Enter number: ");
    scanf("%d", &num);

    if (num <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    checkTribonacci(num);

    return 0;
}
