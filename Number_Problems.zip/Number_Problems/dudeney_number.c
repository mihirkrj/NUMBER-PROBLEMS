#include <stdio.h>
#include <math.h>

_Bool checkDudeney(int num)
{
    int sumDigits = 0;
    int originalNum = num;

    while (num > 0)
    {
        sumDigits += num % 10;
        num /= 10;
    }

    return sumDigits == (int)cbrt(originalNum);
}

int main()
{
    int input;
    printf("Enter a number: ");
    scanf("%d", &input);

    if (input <= 0)
    {
        printf("Invalid input. Please enter a positive number.\n");
        return 1;
    }

    if (checkDudeney(input))
    {
        printf("This number is a Dudeney Number.\n");
    }
    else
    {
        printf("This number is not a Dudeney Number.\n");
    }

    return 0;
}
