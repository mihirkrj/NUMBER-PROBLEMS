#include <stdio.h>
#include <stdbool.h>

int sumOfDigits(int number)
{
    int digitSum = 0;
    while (number > 0)
    {
        digitSum += number % 10;
        number /= 10;
    }
    return digitSum;
}

_Bool checkNivenNumber(int number)
{
    int digitSum = sumOfDigits(number);
    return (number % digitSum == 0);
}

int main()
{
    int number;

    printf("Enter a number: ");
    if (scanf("%d", &number) != 1 || number <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (checkNivenNumber(number))
    {
        printf("The number is a Niven Number.\n");
    }
    else
    {
        printf("The number is not a Niven Number.\n");
    }

    return 0;
}
