#include <stdio.h>

_Bool checkBuzz(int num)
{
    return (num % 10 == 7) || (num % 7 == 0);
}

int main()
{
    int input;
    printf("Enter a number: ");
    scanf("%d", &input);

    if (input <= 0)
    {
        printf("Invalid input. Please enter a positive number.\n");
        return 1;
    }

    if (checkBuzz(input))
    {
        printf("This number is a Buzz Number.\n");
    }
    else
    {
        printf("This number is not a Buzz Number.\n");
    }

    return 0;
}
