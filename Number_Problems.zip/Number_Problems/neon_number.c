#include <stdio.h>
#include <stdbool.h>
#include <math.h>

_Bool isNeonNumber(int number)
{
    int sum = 0, squaredValue = number * number;
    while (squaredValue > 0)
    {
        sum += squaredValue % 10;
        squaredValue /= 10;
    }
    return sum == number;
}

int main()
{
    int x;
    printf("Enter a number: ");
    scanf("%d", &x);

    if (x <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (isNeonNumber(x))
    {
        printf("The number is a Neon Number.\n");
    }
    else
    {
        printf("The number is not a Neon Number.\n");
    }

    return 0;
}
