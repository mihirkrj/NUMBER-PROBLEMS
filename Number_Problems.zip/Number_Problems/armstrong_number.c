#include <stdio.h>
#include <math.h>

_Bool checkArmstrong(int num)
{
    int originalNum = num, digitCount = 0, result = 0;

    // Calculate the number of digits
    for (int temp = num; temp > 0; temp /= 10)
    {
        digitCount++;
    }

    // Calculate the sum of each digit raised to the power of digitCount
    for (int temp = num; temp > 0; temp /= 10)
    {
        result += pow(temp % 10, digitCount);
    }

    return result == originalNum;
}

int main()
{
    int input;
    printf("Enter a number: ");
    scanf("%d", &input);

    if (input <= 0)
    {
        printf("Invalid Input. Please enter a positive number.\n");
        return 1;
    }

    if (checkArmstrong(input))
    {
        printf("This number is an Armstrong Number.\n");
    }
    else
    {
        printf("This number is not an Armstrong Number.\n");
    }

    return 0;
}
