#include <stdio.h>

_Bool checkAbundance(int num)
{
    int divisorSum = 0;
    for (int i = 1; i < num; i++)
    {
        if (num % i == 0)
        {
            divisorSum += i;
        }
    }
    return divisorSum > num;
}

int main()
{
    int inputNum;
    printf("Enter a number: ");
    scanf("%d", &inputNum);

    if (inputNum <= 0)
    {
        printf("Invalid input. Please enter a positive number.\n");
        return 1;
    }

    if (checkAbundance(inputNum))
    {
        printf("This is an Abundant Number.\n");
    }
    else
    {
        printf("This is not an Abundant Number.\n");
    }

    return 0;
}
