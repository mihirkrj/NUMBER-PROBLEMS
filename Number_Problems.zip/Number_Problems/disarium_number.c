#include <stdio.h>
#include <math.h>

_Bool checkDisarium(int num)
{
    int digitCount = 0, sum = 0;
    int originalNum = num;

    // Determine the number of digits
    for (int temp = num; temp > 0; temp /= 10)
    {
        digitCount++;
    }

    // Calculate the sum of digits powered by their respective positions
    for (int temp = num; temp > 0; temp /= 10)
    {
        int digit = temp % 10;
        sum += (int)pow(digit, digitCount);
        digitCount--;
    }

    return sum == originalNum;
}

int main()
{
    int input;
    printf("Enter a number: ");
    scanf("%d", &input);

    if (input <= 0)
    {
        printf("Invalid input. Please enter a positive number.\n");
        return 1;
    }

    if (checkDisarium(input))
    {
        printf("This number is a Disarium Number.\n");
    }
    else
    {
        printf("This number is not a Disarium Number.\n");
    }

    return 0;
}
