#include <stdio.h>
#include <math.h>
#include <stdbool.h>

_Bool isTech(int number, int digits)
{
    int mid = digits / 2;
    int divisor = pow(10, mid);
    int firstPart = number / divisor;
    int secondPart = number % divisor;

    int sum = firstPart + secondPart;
    return (sum * sum == number);
}

int main()
{
    int num, digits = 0;
    printf("Enter a number: ");
    scanf("%d", &num);

    // Count the number of digits
    int temp = num;
    while (temp > 0)
    {
        digits++;
        temp /= 10;
    }

    if (num <= 0 || digits % 2 != 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (isTech(num, digits))
    {
        printf("The number is a Tech Number.\n");
    }
    else
    {
        printf("The number is not a Tech Number.\n");
    }

    return 0;
}
