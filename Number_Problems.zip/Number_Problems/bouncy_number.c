#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

_Bool checkIfBouncy(int num)
{
    int prevDigit = num % 10;
    num /= 10;
    _Bool isIncreasing = false, isDecreasing = false;

    while (num > 0)
    {
        int currentDigit = num % 10;

        if (currentDigit < prevDigit)
            isIncreasing = true;
        else if (currentDigit > prevDigit)
            isDecreasing = true;

        if (isIncreasing && isDecreasing)
            return 1;

        prevDigit = currentDigit;
        num /= 10;
    }
    return 0;
}

int main()
{
    int inputNum;
    printf("Enter a number: ");
    scanf("%d", &inputNum);

    if (inputNum < 100)
    {
        printf("A Bouncy Number requires at least three digits.\n");
    }
    else
    {
        if (checkIfBouncy(inputNum))
        {
            printf("This is a Bouncy Number.\n");
        }
        else
        {
            printf("This is not a Bouncy Number.\n");
        }
    }

    return 0;
}
