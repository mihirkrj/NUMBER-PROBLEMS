#include <stdio.h>
#include <stdbool.h>

_Bool isHarshadNumber(int number)
{
    int sum = 0, temp = number;

    while (temp > 0)
    {
        sum += temp % 10;
        temp /= 10;
    }
    return (number % sum == 0);
}

int main()
{
    int x;
    printf("Enter a number: ");
    scanf("%d", &x);

    if (x <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    if (isHarshadNumber(x))
    {
        printf("The number is a Harshad Number.\n");
    }
    else
    {
        printf("The number is not a Harshad Number.\n");
    }

    return 0;
}
