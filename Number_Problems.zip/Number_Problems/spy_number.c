#include <stdio.h>
#include <stdbool.h>

_Bool isSpy(int number)
{
    int sum = 0, product = 1;

    while (number > 0)
    {
        int digit = number % 10;
        sum += digit;
        product *= digit;
        number /= 10;
    }

    return sum == product;
}

int main()
{
    int num;
    printf("Please enter a number: ");

    // Check for valid input
    if (scanf("%d", &num) != 1 || num <= 0)
    {
        printf("Invalid Input\n");
        return -1;
    }

    // Check if the number is a Spy Number
    if (isSpy(num))
    {
        printf("The number is a Spy Number.\n");
    }
    else
    {
        printf("The number is not a Spy Number.\n");
    }

    return 0;
}
